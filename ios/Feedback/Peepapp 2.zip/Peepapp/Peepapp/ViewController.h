//
//  ViewController.h
//  Peepapp
//
//  Created by Andris Konfar on 19/09/14.
//  Copyright (c) 2014 Andris Konfar. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SRWebSocket.h"

@interface ViewController : UIViewController <SRWebSocketDelegate>


@end

