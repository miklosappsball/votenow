//
//  ButtonUtil.h
//  Peepapp
//
//  Created by Andris Konfar on 24/09/14.
//  Copyright (c) 2014 Andris Konfar. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ButtonUtil : NSObject

+ (UIButton*) createButton;

@end
