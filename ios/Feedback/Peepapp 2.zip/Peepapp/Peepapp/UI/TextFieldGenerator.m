//
//  TextFieldGenerator.m
//  Peepapp
//
//  Created by Andris Konfar on 24/09/14.
//  Copyright (c) 2014 Andris Konfar. All rights reserved.
//

#import "TextFieldGenerator.h"

@implementation TextFieldGenerator

- (UITextField*) createTextField
{
    UITextField* textField = [[UITextField alloc] init];
    
    return textField;
}

@end
