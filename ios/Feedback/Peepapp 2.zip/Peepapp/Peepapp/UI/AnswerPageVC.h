//
//  AnswerPageVC.h
//  Peepapp
//
//  Created by Andris Konfar on 03/10/14.
//  Copyright (c) 2014 Andris Konfar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AnswerPageVC : UIViewController

- (instancetype)initWithPushId:(NSString*) pushId;

@end
