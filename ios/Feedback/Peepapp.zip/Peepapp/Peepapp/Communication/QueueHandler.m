//
//  QueueHandler.m
//  Peepapp
//
//  Created by Andris Konfar on 10/10/14.
//  Copyright (c) 2014 Andris Konfar. All rights reserved.
//

#import "QueueHandler.h"

#define QUEUE @"PUSHDATA_QUEUE"

@implementation QueueHandler

- (void) addObjectToQueue:(PushData*)pd
{
    NSUserDefaults* defaults = [NSUserDefaults standardUserDefaults];
    NSMutableArray* array = [defaults objectForKey:QUEUE];
    if(array == nil) array = [[NSMutableArray alloc] init];
    array = [[NSMutableArray alloc] initWithArray:array];
    [array addObject:[pd dictionaryRepr]];
    [defaults setObject:array forKey:QUEUE];
    [defaults synchronize];
}

- (PushData*) getNextItem
{
    NSUserDefaults* defaults = [NSUserDefaults standardUserDefaults];
    NSMutableArray* array = [defaults objectForKey:QUEUE];
    if(array == nil || array.count == 0) return nil;
    PushData* pd = [[PushData alloc] initFromDictionary:array[0]];
    [array removeObjectAtIndex:0];
    [defaults setObject:array forKey:QUEUE];
    [defaults synchronize];
    return pd;
}

@end
