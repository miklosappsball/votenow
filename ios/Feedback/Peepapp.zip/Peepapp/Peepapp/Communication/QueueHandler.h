//
//  QueueHandler.h
//  Peepapp
//
//  Created by Andris Konfar on 10/10/14.
//  Copyright (c) 2014 Andris Konfar. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PushData.h"

@interface QueueHandler : NSObject

- (void) addObjectToQueue:(PushData*)pd;
- (PushData*) getNextItem;

@end
