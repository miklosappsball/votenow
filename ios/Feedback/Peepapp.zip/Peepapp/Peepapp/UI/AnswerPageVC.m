//
//  AnswerPageVC.m
//  Peepapp
//
//  Created by Andris Konfar on 03/10/14.
//  Copyright (c) 2014 Andris Konfar. All rights reserved.
//

#import "AnswerPageVC.h"
#import "LoadingIndicatorViewController.h"
#import "Communication.h"
#import <AudioToolbox/AudioToolbox.h>
#import "CameraVC.h"
#import "GAIDictionaryBuilder.h"

@interface AnswerPageVC ()
{
    UIImageView * imageView;
}

@end

@implementation AnswerPageVC

- (instancetype)initWithPushId:(NSString*) pushId
{
    self = [super init];
    if (self) {
        
        id<GAITracker> tracker = [[GAI sharedInstance] defaultTracker];
        [tracker set:kGAIScreenName value:@"AnswerPage"];
        [tracker send:[[GAIDictionaryBuilder createAppView] build]];
        
        self.view.backgroundColor = COLOR_BACKGROUND_1;
        
        [LOADING_INDICATOR showLoadingIndicator];
        
        imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 80, self.view.frame.size.width, self.view.frame.size.width)];
        
        [self.view addSubview:imageView];
        
        
        UILabel* label = [[UILabel alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height-100, self.view.frame.size.width, 100)];
        label.font = [UIFont boldSystemFontOfSize:32];
        label.backgroundColor = [UIColor clearColor];
        label.textColor = TEXT_COLOR_1;
        label.textAlignment = NSTextAlignmentCenter;
        [self.view addSubview:label];
        
        [[Communication instance] downloadImage:pushId answerFunction: ^(NSDictionary* answer){
            NSString* message = [answer objectForKey:FIELD_MESSAGE];
            if([@"DATA_RECEIVED" isEqualToString:message])
            {
                if(SHUTTER)
                {
                    AudioServicesPlayAlertSound(kSystemSoundID_Vibrate);
                }
                [LOADING_INDICATOR hideLoadingIndicator];
                NSLog(@"downloaded");
                NSData* data = [[Communication instance] lastReceivedData];
                UIImage* image = [UIImage imageWithData:data];
                [imageView setImage:image];
                [CameraVC calculateBackward:label int:3 endString:@"DELETED!"];
                
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                    [NSThread sleepForTimeInterval:3];
                    dispatch_async(dispatch_get_main_queue(), ^{
                        imageView.image = nil;
                    });
                });
                
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                    [NSThread sleepForTimeInterval:4];
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [self.navigationController popViewControllerAnimated:YES];
                    });
                });

            }
            else NSLog(@"%@", answer);
        }];
        
    }
    return self;
}

@end
