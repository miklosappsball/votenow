//
//  ContactsVC.m
//  Peepapp
//
//  Created by Andris Konfar on 24/09/14.
//  Copyright (c) 2014 Andris Konfar. All rights reserved.
//

#import "ContactsVC.h"
#import "ButtonUtil.h"
#import "LoadingIndicatorViewController.h"
#import "Communication.h"
#import "CameraVC.h"
#import <AddressBook/AddressBook.h>
#import "PushData.h"
#import <MessageUI/MessageUI.h>
#import "DeviceUtil.h"
#import "AnswerPageVC.h"
#import "GAIDictionaryBuilder.h"

@interface ContactsVC ()
{
    UITextField* tfPhoneTo;
    UISwitch* sw;
    UIView* lastContactsView;
}

@end

@implementation ContactsVC

- (instancetype)init
{
    self = [super init];
    if (self) {
        
        id<GAITracker> tracker = [[GAI sharedInstance] defaultTracker];
        [tracker set:kGAIScreenName value:@"Contacts"];
        [tracker send:[[GAIDictionaryBuilder createAppView] build]];
        
        self.title = @"Peek request";
        [self.navigationItem setHidesBackButton:YES animated:YES];
        self.view.backgroundColor = COLOR_BACKGROUND_1;
        
        UIScrollView* scrollview = [[UIScrollView alloc] initWithFrame:self.view.bounds];
        scrollview.autoresizingMask = UIViewAutoresizingFlexibleWidth;
        [self.view addSubview:scrollview];
        
        CGFloat y = DEFAULT_GAP;
        
        UIView* tfView = [[UIView alloc] initWithFrame:CGRectMake(0, y, self.view.frame.size.width, TEXT_FIELD_HEIGHT*2)];
        tfView.layer.borderWidth = 0.5;
        tfView.layer.borderColor = [BORDER_COLOR CGColor];
        tfView.autoresizingMask = UIViewAutoresizingFlexibleWidth;
        tfView.backgroundColor = ITEM_BG_COLOR;
        [scrollview addSubview:tfView];
        
        UIView* separator = [[UIView alloc] initWithFrame:CGRectMake(LEFT_MARGIN, TEXT_FIELD_HEIGHT, self.view.frame.size.width-LEFT_MARGIN, 0.5f)];
        separator.backgroundColor = BORDER_COLOR;
        [tfView addSubview:separator];
        
        UILabel* label = [[UILabel alloc] initWithFrame:CGRectMake(LEFT_MARGIN, 0, self.view.frame.size.width-LEFT_MARGIN, TEXT_FIELD_HEIGHT)];
        label.backgroundColor = [UIColor clearColor];
        label.textColor = TEXT_COLOR_1;
        label.text = @"Anonym peek";
        [tfView addSubview:label];
        
        sw = [[UISwitch alloc] init];
        sw.frame = CGRectMake(self.view.frame.size.width - RIGHT_MARGIN - sw.frame.size.width, (TEXT_FIELD_HEIGHT - sw.frame.size.height)/2, sw.frame.size.width, sw.frame.size.height);
        sw.tintColor = BORDER_COLOR;
        sw.onTintColor = TEXT_COLOR_1;
        [tfView addSubview:sw];
        
        tfPhoneTo = [[UITextField alloc] init];
        tfPhoneTo.frame = CGRectMake(LEFT_MARGIN, TEXT_FIELD_HEIGHT, self.view.frame.size.width-LEFT_MARGIN, TEXT_FIELD_HEIGHT);
        tfPhoneTo.text = @"";
        tfPhoneTo.textColor = TEXT_COLOR_1;
        tfPhoneTo.keyboardType = UIKeyboardTypePhonePad;
         [tfView addSubview:tfPhoneTo];
        
        UIButton* button = [UIButton buttonWithType:UIButtonTypeContactAdd];
        button.frame = CGRectMake(self.view.frame.size.width - RIGHT_MARGIN - button.frame.size.width, TEXT_FIELD_HEIGHT + (TEXT_FIELD_HEIGHT - button.frame.size.height)/2, button.frame.size.width, button.frame.size.height);
        [button addTarget:self action:@selector(showContacts) forControlEvents:UIControlEventTouchUpInside];
        [tfView addSubview:button];
        
        y += TEXT_FIELD_HEIGHT*2 + DEFAULT_GAP;
        
        button = [ButtonUtil createButton];
        [button setTitle:@"Peek at her/him!" forState:UIControlStateNormal];
        button.frame = CGRectMake(-0.5, y, self.view.frame.size.width+1, BUTTON_HEIGHT);
        [button addTarget:self action:@selector(startpeep) forControlEvents:UIControlEventTouchUpInside];
        [scrollview addSubview:button];
        
        y += button.frame.size.height + DEFAULT_GAP;
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(LEFT_MARGIN, y, self.view.frame.size.width-LEFT_MARGIN-LEFT_MARGIN, TEXT_FIELD_HEIGHT)];
        label.backgroundColor = [UIColor clearColor];
        label.textColor = TEXT_COLOR_1;
        label.text = @"Last contacts:";
        [scrollview addSubview:label];
        
        y += TEXT_FIELD_HEIGHT;
        lastContactsView = [[UIView alloc] initWithFrame:CGRectMake(-1, y, self.view.frame.size.width+2, self.view.frame.size.height-y)];
        lastContactsView.layer.borderWidth = 0.5;
        lastContactsView.layer.borderColor = [BORDER_COLOR CGColor];
        [scrollview addSubview:lastContactsView];
        [self createLastContacts];
    }
    return self;
}

- (void)viewDidAppear:(BOOL)animated
{
    [self createLastContacts];
}

- (void) createLastContacts
{
    for(UIView* v in lastContactsView.subviews) [v removeFromSuperview];
    
    CGFloat y=0;
    NSArray* array = [[NSUserDefaults standardUserDefaults] objectForKey:LAST_CONTACTS_UD];
    if(array == nil) return;
    
    int i=0;
    for(NSDictionary* d in array)
    {
        PushData* pd = [[PushData alloc] initFromDictionary:d];
        UIButton* button = [ButtonUtil createButton];
        button.backgroundColor = [UIColor clearColor];
        button.layer.borderWidth = 0;
        [button setTitle:[NSString stringWithFormat:@"%@ (%@)", pd.phoneNumber, pd.name] forState:UIControlStateNormal];
        button.frame = CGRectMake(-0.5, y, self.view.frame.size.width+1, BUTTON_HEIGHT);
        [button addTarget:self action:@selector(setAsContact:) forControlEvents:UIControlEventTouchUpInside];
        [lastContactsView addSubview:button];
        button.tag = i++;
        y += button.frame.size.height;
        
        UIView* separator = [[UIView alloc] initWithFrame:CGRectMake(LEFT_MARGIN, y, self.view.frame.size.width-LEFT_MARGIN, 0.5f)];
        separator.backgroundColor = BORDER_COLOR;
        [lastContactsView addSubview:separator];
    }
}

- (void) setAsContact:(UIButton*) button
{
    NSArray* array = [[NSUserDefaults standardUserDefaults] objectForKey:LAST_CONTACTS_UD];
    NSDictionary* d = array[button.tag];
    PushData* pd = [[PushData alloc] initFromDictionary:d];
    
    id<GAITracker> tracker = [[GAI sharedInstance] defaultTracker];
    [tracker send:[[GAIDictionaryBuilder createEventWithCategory:@"PP"
                                                          action:@"touch"
                                                           label:@"startpeep_lastContact"
                                                           value:nil] build]];
    
    [self startpeep:pd.phoneNumber];
}

- (void) showContacts
{
    id<GAITracker> tracker = [[GAI sharedInstance] defaultTracker];
    [tracker send:[[GAIDictionaryBuilder createEventWithCategory:@"PP"
                                                          action:@"touch"
                                                           label:@"showcontacts"
                                                           value:nil] build]];
    
    ABPeoplePickerNavigationController *picker = [[ABPeoplePickerNavigationController alloc] init];
    picker.peoplePickerDelegate = self;
    if([picker respondsToSelector:@selector(setPredicateForEnablingPerson:)]) picker.predicateForEnablingPerson = [NSPredicate predicateWithFormat:@"%K.@count > 0", ABPersonPhoneNumbersProperty];
    picker.displayedProperties = [NSArray arrayWithObjects:[NSNumber numberWithInt:kABPersonPhoneProperty],nil];
    [self presentViewController:picker animated:YES completion:nil];
}

- (BOOL)peoplePickerNavigationController:(ABPeoplePickerNavigationController *)peoplePicker shouldContinueAfterSelectingPerson:(ABRecordRef)person
{
    return YES;
}

- (BOOL)peoplePickerNavigationController:(ABPeoplePickerNavigationController *)peoplePicker shouldContinueAfterSelectingPerson:(ABRecordRef)person property:(ABPropertyID)property identifier:(ABMultiValueIdentifier)identifier
{
    [self dismissViewControllerAnimated:YES completion:nil];
    [self peoplePickerNavigationController:peoplePicker didSelectPerson:person property:property identifier:identifier];
    return NO;
}

- (void)peoplePickerNavigationController:(ABPeoplePickerNavigationController *)peoplePicker didSelectPerson:(ABRecordRef)person property:(ABPropertyID)property identifier:(ABMultiValueIdentifier)identifier
{
    ABMultiValueRef phoneProperty = ABRecordCopyValue(person,property);
    CFIndex peopleIndex = ABMultiValueGetIndexForIdentifier(phoneProperty, identifier);
    NSString *phone = (__bridge_transfer NSString*)ABMultiValueCopyValueAtIndex(phoneProperty, peopleIndex);
    
    NSMutableString* str = [[NSMutableString alloc] initWithCapacity:phone.length];
    for(int i=0;i<phone.length;i++)
    {
        if([phone characterAtIndex:i] == '+')
        {
            [str appendString:@"+"];
        }
        if([phone characterAtIndex:i] >= '0' && [phone characterAtIndex:i] <= '9')
        {
            [str appendFormat:@"%c", [phone characterAtIndex:i]];
        }
    }
    
    NSLog(@"name: %@", [self getName:person]);
    
    tfPhoneTo.text = str;
}

- (void)peoplePickerNavigationControllerDidCancel:(ABPeoplePickerNavigationController *)peoplePicker
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(buttonIndex == 1)
    {
        id<GAITracker> tracker = [[GAI sharedInstance] defaultTracker];
        [tracker send:[[GAIDictionaryBuilder createEventWithCategory:@"PP"
                                                              action:@"touch"
                                                               label:@"peekback"
                                                               value:nil] build]];
        [self startpeep:[DeviceUtil peekBackNumber]];
    }
}

- (NSString*) getName:(ABRecordRef)ref
{
    NSString *firstName = (__bridge_transfer NSString *)ABRecordCopyValue(ref, kABPersonFirstNameProperty);
    NSString *lastName = (__bridge_transfer NSString *)ABRecordCopyValue(ref, kABPersonLastNameProperty);
    if(firstName == nil || [@"(null)" isEqualToString:firstName] || firstName.length == 0) firstName = nil;
    if(lastName == nil || [@"(null)" isEqualToString:lastName] || lastName.length == 0) lastName = nil;
    NSString *fullName = nil;
    if(firstName == nil)
    {
        fullName = lastName;
    }
    if (lastName == nil)
    {
        fullName = firstName;
    }
    if(fullName == nil)
    {
        if (ABPersonGetCompositeNameFormat() == kABPersonCompositeNameFormatFirstNameFirst)
        {
            fullName = [NSString stringWithFormat:@"%@ %@", firstName, lastName];
        }
        else
        {
            fullName = [NSString stringWithFormat:@"%@, %@", lastName, firstName];
        }
    }
    
    return fullName;
}

- (void) startpeep
{
    id<GAITracker> tracker = [[GAI sharedInstance] defaultTracker];
    [tracker send:[[GAIDictionaryBuilder createEventWithCategory:@"PP"
                                                          action:@"touch"
                                                           label:@"startpeep_button"
                                                           value:nil] build]];
    
    [self startpeep:tfPhoneTo.text];
}

- (void) startpeep:(NSString*) phone_to
{
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
    [LOADING_INDICATOR showLoadingIndicator];
    
    [[Communication instance] peepNumber:phone_to anonymus:sw.on answerFunction:^(NSDictionary* answer)
     {
         [LOADING_INDICATOR hideLoadingIndicator];
         [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
         
         NSString* msg = [answer objectForKey:FIELD_MESSAGE];
         if([msg isEqualToString:@"SUCCESS"])
         {
             [[[UIAlertView alloc] initWithTitle:@"Peek" message:@"Succesfull peek request!" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles: nil] show];
         }
         else if([msg isEqualToString:@"SMS_NEEDED"])
         {
             MFMessageComposeViewController *controller = [[MFMessageComposeViewController alloc] init];
             if([MFMessageComposeViewController canSendText])
             {
                 controller.body = @"Hey there, I want to take a peek at you right now, please install peekapp in https://appsball.com/peekappinstall and let me take a peek at you!";
                 controller.recipients = [NSArray arrayWithObjects:tfPhoneTo.text, nil];
                 controller.messageComposeDelegate = self; 
                 [self presentViewController:controller animated:YES completion:nil];
             }
         }
         else
         {
             [[[UIAlertView alloc] initWithTitle:@"Error" message:@"Error in communication, please try again!" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles: nil] show];
         }
     }];
}

- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result
{
    NSLog(@"returned");
    [self dismissViewControllerAnimated:YES completion:nil];
}

@end
